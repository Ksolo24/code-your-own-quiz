blanks = ["__1__", "__2__", "__3__","__4__"]

#Quiz
easy_quiz = "Similar to how strings are seuqences of characters, __1__ are sequences of anything. __2__ loops make iterating through elements in a list easier than using a while loop. __3__ are nothing but reserved memory locations to store values. __4__ loops can use one or more loop inside any another while, for or do..while loop."
medium_quiz = "__1__ loop repeats a statement or group of statements while a given condition is TRUE. __2__ terminates the loop statement and transfers execution to the statement immediately following the loop. __3__ are amongst the most popular types in Python. We can create them simply by enclosing characters in quotes. __4__is a block of organized, reusable code that is used to perform a single, related action."
hard_quiz = "__1__ are the constructs which can manipulate the value of operands. Consider the expression 4 + 5 = 9. Here, 4 and 5 are called __2__ and + is called operator. Function blocks begin with the keyword __3__ followed by the function name and parentheses ( ( ) ). __4__ is a general-purpose interpreted, interactive, object-oriented, and high-level programming language. It was created by Guido van Rossum during 1985 - 1990."

#Answers
answer_easy = ["list", "for", "variable", "nested"]
answer_medium = ["while", "break", "string",'function']
answer_hard = ["operator", "operand", "def", "python"]

print ("Welcome to Kanan's Fill in the Blanks Quiz.")

#prompts user to choose difficulty
user_input = raw_input("Please choose a difficulty level. Press 1 for easy, 2 for medium and 3 for hard then hit return.")


#Choose difficulty
def difficulty(user_input):
    if user_input == "1":
        print "You've chosen easy."
        return easy_quiz
    elif user_input == "2":
        print "You've chosen medium."
        return medium_quiz
    elif user_input == "3":
        print "You've chosen hard."
        return hard_quiz 
print(difficulty(user_input))

#this function returns the answers
def answer(user_input):
    if difficulty(user_input) == "1":
        print(answer_easy)
        return easy_quiz
    elif difficulty(user_input) == "2":
        print(answer_medium)
        return medium_quiz
    elif difficulty(user_input) == "3":
        print(answer_hard)
        return hard_quiz

#checks if the answer is right or wrong  
def check_answer():
    question_number = 0
    wrong = 0
    answers = 0
    while question_number < 4:
        user_answer = raw_input("What is the answer for" + blanks[question_number] + "?")
        if user_answer == answer_easy[question_number]:
            question_number += 1
            print("Correct")
        else:
            question_number += 1
            wrong = wrong + 1
            print("Incorrect")
            



print(check_answer())
print(wrong)
